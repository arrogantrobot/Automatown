#ifndef CHANGE_H
#define CHANGE_H

struct change{
	int location;
	int structure;
};

#endif
