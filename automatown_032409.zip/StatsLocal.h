#ifndef STATS_LOCAL
#define STATS_LOCAL

struct statsLocal{
	int population,
		jobs,
		iDem,
		cDem,
		rDem,
		nearRoad;
};
#endif
