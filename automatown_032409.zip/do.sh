make clean
make
./automatown
