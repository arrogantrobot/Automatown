#ifndef BUILD_VALS_H
#define BUILD_VALS_H


#define C_MIN 50
#define C_MIN_B 100
#define R_MIN 30



#endif
